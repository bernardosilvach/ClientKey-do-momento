let botao = document.getElementById('botaocadastrar');

botao.onclick = async function(e) {
    e.preventDefault();

    var email = document.getElementById('email').value;
    var nome = document.getElementById('nome').value;
    var cpf = document.getElementById('cpf').value;
    var senha = document.getElementById('senha').value;

    if (!email || !nome || !cpf || !senha) {
        alert('Preencha todos os campos!');
        return false;
    } else {
        let data = {nome,cpf,email,senha};

        const response = await fetch('http://localhost:3000/api/store/users', {
            method: 'POST',
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(data)
        })

        let content = await response.json()

        if (content.success) {
            alert('Cadastro realizado com sucesso!')
            
        } else {
            alert('Erro ao realizar cadastro!')
        }
    }
}