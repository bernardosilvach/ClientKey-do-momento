let interior = document.getElementById('interiorbaixo')


document.addEventListener('DOMContentLoaded',  async function mostrarClientes(event) {
        event.preventDefault();

        const name = localStorage.getItem('nome_user');
        const usuarioatual = document.getElementById("usuarioatual");
        usuarioatual.textContent = name

        const usuario_relacionado = localStorage.getItem('id_user');

        let data = {usuario_relacionado}
        // console.log(usuario_relacionado)

        const response = await fetch('http://localhost:3000/api/store/mostrarClientes', {
            method: 'POST',
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(data)
        })

        let content = await response.json()
        console.log(content)

        if(content.success) {
            content.data.forEach(function(mostrar) {
                console.log(mostrar);

                let card = document.createElement("div");
                card.classList.add("card"); // Adiciona a classe 'card' ao elemento

                const nome = mostrar.nome;
                const cpf = mostrar.cpf;
                const email = mostrar.email;
                const telefone = mostrar.telefone;
                const endereco = mostrar.adress;
                const statuscl = mostrar.statuscl;

                // Define o conteúdo HTML do card com os valores capturados do formulário
                const cardContent = `
                        <h3>${nome}</h3>
                        <p>CPF: ${cpf}</p>
                        <p>Email: ${email}</p>
                        <p>Telefone: ${telefone}</p>
                        <p>Endereço: ${endereco}</p>
                        <p>Status: ${statuscl}</p>
                    `;

                    card.innerHTML = cardContent
                    interior.appendChild(card)
            })
        }
    })



let abrir_form = document.getElementById("abrir_form")

abrir_form.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")

    modal_teste.style.display = "block"
})

let close = document.getElementById("close")

close.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")
    modal_teste.style.display = "none"
})


async function handleSubmit(event) {
    event.preventDefault();



    let nome = document.getElementById("nome").value;
    let cpf = document.getElementById("cpf").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let endereco = document.getElementById("endereco").value;
    let status = document.getElementById("status").value;
    const usuario_relacionado = localStorage.getItem('id_user');

    const data = {
        nome,
        cpf,
        email,
        telefone,
        endereco,
        status,
        usuario_relacionado
    }


    const response = await fetch('http://localhost:3000/api/store/clientes', {
        method: 'POST',
        headers: { "Content-type": "application/json;charset=UTF-8" },
        body: JSON.stringify(data)
    })

    let content = await response.json()

    if (content.success) {

        var card = document.createElement("div");
        card.classList.add("card"); // Adiciona a classe 'card' ao elemento

        // Define o conteúdo HTML do card com os valores capturados do formulário
        card.innerHTML = `
                <h3>${nome}</h3>
                <p>CPF: ${cpf}</p>
                <p>Email: ${email}</p>
                <p>Telefone: ${telefone}</p>
                <p>Endereço: ${endereco}</p>
                <p>Status: ${status}</p>
            `;

        document.querySelector(".interiorbaixo").appendChild(card);

        document.getElementById("myForm").reset();

        let modal_teste = document.getElementById("id01")

        modal_teste.style.display = 'none'
    } else {
        alert("Erro ao cadastrar cliente!");
    }

}