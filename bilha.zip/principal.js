const botao_criar_editar = document.getElementById('botao_criar_editar');

let interior = document.getElementById('interiorbaixo');

document.addEventListener('DOMContentLoaded', function () {
    const name = localStorage.getItem('nome_user');
    const usuarioatual = document.getElementById("usuarioatual");
    usuarioatual.textContent = name

    const nomenegocio = localStorage.getItem('nome_negocio');
    const negocioatual = document.getElementById("negocioatual");
    negocioatual.textContent = nomenegocio
})


document.addEventListener('DOMContentLoaded', async function mostrarClientes(event) {
    event.preventDefault();

    const usuario_relacionado = localStorage.getItem('id_user');
    let data = { usuario_relacionado };

    const response = await fetch('http://localhost:3000/api/store/mostrarClientes', {
        method: 'POST',
        headers: { "Content-type": "application/json;charset=UTF-8" },
        body: JSON.stringify(data)
    });

    let content = await response.json();

    if (content.success) {
        content.data.forEach(function (mostrar) {
            const card = document.createElement("div");
            card.classList.add("card");
            const botoes = document.createElement("div");
            botoes.classList.add("botoes");
            const card_total = document.createElement("div");
            card_total.classList.add("card_total");

            const nome = mostrar.nome;
            const cpf = mostrar.cpf;
            const email = mostrar.email;
            const telefone = mostrar.telefone;
            const endereco = mostrar.adress;
            const statuscl = mostrar.statuscl;
            const id = mostrar.id;

            const cardContent = `
                <div id="cliente_card">
                    <h3>${nome}</h3>
                    <p>CPF: ${cpf}</p>
                    <p>Email: ${email}</p>
                    <p>Telefone: ${telefone}</p>
                    <p>Endereço: ${endereco}</p>
                    <p>Status: ${statuscl}</p>
                </div>
            `;

            card.innerHTML = cardContent;
            botoes.innerHTML = `
                <button class="botao_editar">Editar</button>
                <button class="botao_excluir">Excluir</button>
            `;

            interior.appendChild(card_total);
            card_total.appendChild(card);
            card_total.appendChild(botoes);

            // Evento para editar o cliente
            // Evento de clique no botão "Editar"
            botoes.querySelector('.botao_editar').addEventListener('click', function () {
                // Preenche os campos do formulário com os dados do cliente existente
                document.getElementById('nome').value = nome;
                document.getElementById('cpf').value = cpf;
                document.getElementById('email').value = email;
                document.getElementById('telefone').value = telefone;
                document.getElementById('endereco').value = endereco;
                document.getElementById('status').value = statuscl;
                localStorage.setItem('cliente_id', id); // Armazena o ID do cliente a ser atualizado
                
                let modal_teste = document.getElementById("id01");
                modal_teste.style.display = "block"; // Abre o modal

                botao_criar_editar.id = 'botao_criar_editar';
                botao_criar_editar.textContent = 'Editar';


                botao_criar_editar.removeAttribute('onclick', 'handleSubmit(event)');

                // Remove qualquer listener anterior para evitar múltiplos eventos
                document.getElementById('botao_criar_editar').addEventListener('click', async function () {
                    // Pega os valores atualizados dos campos do formulário
                    let updatedNome = document.getElementById('nome').value;
                    let updatedCpf = document.getElementById('cpf').value;
                    let updatedEmail = document.getElementById('email').value;
                    let updatedTelefone = document.getElementById('telefone').value;
                    let updatedEndereco = document.getElementById('endereco').value;
                    let updatedStatus = document.getElementById('status').value;
                    let clienteId = localStorage.getItem('cliente_id'); // Obtém o ID do cliente armazenado

                    if (!updatedNome || !updatedTelefone) {
                        alert('Preencha os campos obrigatórios (nome e telefone)!');
                        return;
                    }

                    const data = {
                        nome: updatedNome,
                        cpf: updatedCpf,
                        email: updatedEmail,
                        telefone: updatedTelefone,
                        endereco: updatedEndereco,
                        status: updatedStatus
                    };

                    try {
                        const response = await fetch(`http://localhost:3000/api/store/clientes/${clienteId}`, {
                            method: 'PUT', // Utiliza PUT para atualizar o cliente existente
                            headers: { "Content-type": "application/json;charset=UTF-8" },
                            body: JSON.stringify(data)
                        });

                        let content = await response.json();

                        if (content.success) {
                            alert("Cliente atualizado com sucesso!");
                            modal_teste.style.display = "none"; // Fecha o modal após a atualização
                            location.reload();
                        } else {
                            alert("Erro ao atualizar cliente!");
                        }
                    } catch (error) {
                        console.error('Erro na requisição:', error);
                        alert('Erro ao conectar com o servidor.');
                    }
                });
            });
                       
            // Evento para deletar o cliente
            botoes.querySelector('.botao_excluir').addEventListener('click', async function () {
                const response = await fetch(`http://localhost:3000/api/store/deletarClientes/${id}`, {
                    method: 'DELETE',
                    headers: { 'Content-type': 'application/json;charset=UTF-8' }
                });

                let content = await response.json();

                if (content.success) {
                    alert("SUCESSO AO DELETAR");
                    location.reload(); // Recarrega a página após deletar
                } else {
                    alert("ERRO AO DELETAR");
                }
            });
        });
    }
});


let abrir_form = document.getElementById("abrir_form")

abrir_form.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")

    modal_teste.style.display = "block"
})

let close = document.getElementById("close")

close.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")
    modal_teste.style.display = "none"
})


async function handleSubmit(event) {
    event.preventDefault();

    botao_criar_editar.removeAttribute('id');
    botao_criar_editar.textContent = 'Criar';
    botao_criar_editar.setAttribute('onclick', 'handleSubmit(event)');


    let nome = document.getElementById("nome").value;
    let cpf = document.getElementById("cpf").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let endereco = document.getElementById("endereco").value;
    let status = document.getElementById("status").value;
    const usuario_relacionado = localStorage.getItem('id_user');
    if (!nome || !telefone) {
        alert('Preencha os campos requisitados!')
    } else {
        const data = {
            nome,
            cpf,
            email,
            telefone,
            endereco,
            status,
            usuario_relacionado
        }
    
        const response = await fetch('http://localhost:3000/api/store/clientes', {
            method: 'POST',
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(data)
        })
    
        let content = await response.json()
    
    
            if (content.success) {
                location.reload()
    
                // const card = document.createElement("div");
                // card.classList.add("card"); // Adiciona a classe 'card' ao elemento
                // const botoes = document.createElement("div")
                // botoes.classList.add("botoes")
                // const card_total = document.createElement("div")
                // card_total.classList.add("card_total")
    
                // // Define o conteúdo HTML do card com os valores capturados do formulário
                // const cardContent = `
                //         <div id = "cliente_card">
                //             <h3>${nome}</h3>
                //             <p>CPF: ${cpf}</p>
                //             <p>Email: ${email}</p>
                //             <p>Telefone: ${telefone}</p>
                //             <p>Endereço: ${endereco}</p>
                //             <p>Status: ${statuscl}</p>
                //         </div>
                //         `;
    
                // card.innerHTML = cardContent
                // botoes.innerHTML = `                    
                //     <button id="botao_editar">Editar</button>
                //     <button id="botao_excluir" class="botao_excluir">Excluir</button>
                // `
                // interior.appendChild(card_total)
                // card_total.appendChild(card)
                // card_total.appendChild(botoes)
    
                // document.getElementById("myForm").reset();
    
                // let modal_teste = document.getElementById("id01")
    
                // modal_teste.style.display = 'none'
            } else {
                alert("Erro ao cadastrar cliente!");
            }
    }
}